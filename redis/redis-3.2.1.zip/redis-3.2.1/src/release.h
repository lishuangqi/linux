#define REDIS_GIT_SHA1 "49d97a33"
#define REDIS_GIT_DIRTY "       0"
#define REDIS_BUILD_ID "michaeldeMacBook-Pro.local-1532655809"
